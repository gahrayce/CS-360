package com.assignments.projectthree;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class LoginActivity extends AppCompatActivity {
    // Views
    EditText username, password;
    UserDatabase databaseController;
    Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Initiate views
        username = findViewById(R.id.usernameText);
        password = findViewById(R.id.passwordText);
        loginButton = findViewById(R.id.loginButton);

        // Initiate database helper
        databaseController = new UserDatabase(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Glean input
                String user = username.getText().toString().trim();
                String pass = password.getText().toString().trim();

                // In case user forgot to enter some data
                if(user.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Enter all credentials.", Toast.LENGTH_SHORT).show();
                }

                else {
                    // Initialize a Boolean that will express login success
                    Boolean credCheck = databaseController.checkLogin(user, pass);

                    // If user and pass match, go to inventory
                    if (credCheck) {
                        Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
                        startActivity(intent);
                        finish();
                    }

                    // Provide login error message
                    else {
                        Toast.makeText(LoginActivity.this, "Invalid credentials.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // 'Register' button onClick method calls this to launch RegisterActivity
    public void initRegister(View view) {
        Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
        startActivity(intent);
    }

    // Debug feature
    // Button onClick method calls this to jump to InventoryActivity
    public void toInventory(View view) {
        Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
        startActivity(intent);
    }

}