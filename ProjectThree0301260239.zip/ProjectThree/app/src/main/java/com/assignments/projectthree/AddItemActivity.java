package com.assignments.projectthree;

import static java.lang.Integer.valueOf;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddItemActivity extends AppCompatActivity {
    // Views
    EditText mName, mType, mNumber;
    InventoryDatabase inventoryController;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initiate views
        mName = findViewById(R.id.editName);
        mType = findViewById(R.id.editType);
        mNumber = findViewById(R.id.editNum);

        // Initiate database helper
        inventoryController = new InventoryDatabase(this);
    }

    public void processItem(View view) {
        // Glean input
        String name = mName.getText().toString().trim();
        String type = mType.getText().toString().trim();
        String number = mNumber.getText().toString().trim();
        int num = Integer.parseInt(number);

        // Calls InventoryDatabase to add item, stores success value in Boolean
        Boolean checkAdd = inventoryController.insertItem(name, type, num);
        if(checkAdd) {
            Toast.makeText(AddItemActivity.this, "Item added to inventory!", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(AddItemActivity.this, "Error processing request.", Toast.LENGTH_SHORT).show();
        }
    }

    // Back to InventoryActivity button
    public void toInventory(View view) {
        Intent intent = new Intent(AddItemActivity.this, InventoryActivity.class);
        startActivity(intent);
    }
}