package com.assignments.projectthree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

public class InventoryDatabase extends SQLiteOpenHelper {
    // Constructor
    public InventoryDatabase(Context context) {
        super(context, "InventoryRepo.db", null, 1);
    }

    // Creates the table
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table Inventory(name TEXT primary key, type TEXT, number INT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer) {
        db.execSQL("drop table if exists Inventory");
        onCreate(db);
    }

    // Add an item
    public Boolean insertItem(String name, String type, int number) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("type", type);
        values.put("number", number);
        long result = db.insert("Inventory", null, values);
        // Change the Bool value based on insert operation success/failure
        if (result==-1) {
            return false;
        }
        else {
            return true;
        }
    }

    // Get item data
    // FIXME: Unused, probably needed for final recycler/card/grid view
    public Cursor getItems() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from InventoryTable", null);
        cursor.close();
        return cursor;
    }

    // Remove item
    // FIXME: Add delete method

    // Update item
    // Include method to notify user when num = 0?
    // FIXME: Add update method

    // Used for adapter getCount method
    public int countRecords() {
        SQLiteDatabase db = this.getWritableDatabase();
        long records = DatabaseUtils.longForQuery(db, "SELECT COUNT(*) FROM table_name", null);
        int numRecords = Math.toIntExact(records);
        return numRecords;
    }
}