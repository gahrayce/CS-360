package com.assignments.projectthree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

public class UserDatabase extends SQLiteOpenHelper {
    // Constructor
    public UserDatabase(Context context) {
        super(context, "UserRepo.db", null, 1);
    }

    // Creates the table
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table Users(username TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer) {
        db.execSQL("drop table if exists Users");
        onCreate(db);
    }

    // Add a user
    public Boolean insertData(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        long result = db.insert("Users", null, values);
        // Change the Bool value based on insert operation success/failure
        if (result==-1) {
            return false;
        }
        else {
            return true;
        }
    }

    // Check whether username exists in table (is taken)
    public Boolean checkUsername(String user) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from Users where username = ?", new String[]{user});
        if (cursor.getCount() > 0) {
            return true;
        }
        else {
            return false;
        }
    }

    // Check for username and password match
    public Boolean checkLogin(String user, String pass) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from Users where username = ? and password = ?", new String[]{user, pass});

        // If there is a match counted, Bool set to true
        if (cursor.getCount() > 0) {
            return true;
        }
        else {
            return false;
        }
    }
}