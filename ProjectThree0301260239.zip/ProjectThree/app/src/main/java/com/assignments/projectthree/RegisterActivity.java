package com.assignments.projectthree;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    // Views
    EditText username, password;
    UserDatabase databaseController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initiate views
        username = findViewById(R.id.username_register_text);
        password = findViewById(R.id.password_register_text);

        // Initiate database helper
        databaseController = new UserDatabase(this);
    }

    public void tryRegister(View view) {
        // Glean input
        String user = username.getText().toString().trim();
        String pass = password.getText().toString().trim();

        // In case user forgot to enter some data
        if(user.isEmpty() || pass.isEmpty()) {
            Toast.makeText(RegisterActivity.this, "Enter all credentials.", Toast.LENGTH_SHORT).show();
        }

        // Calls UserDatabase to insert user and check the success
        else {
            Boolean checkUserTaken = databaseController.checkUsername(user);
            Boolean checkInsertData = databaseController.insertData(user, pass);

            // Notify username taken
            if (checkUserTaken) {
                Toast.makeText(RegisterActivity.this, "Username taken.", Toast.LENGTH_SHORT).show();
            }
            // Notify user registration successful
            if (checkInsertData == true) {
                Toast.makeText(RegisterActivity.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
            }
            // Notify unsuccessful
            else {
                Toast.makeText(RegisterActivity.this, "Failed to register new user.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Return to LoginActivity button
    public void toLogin(View view) {
        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
        startActivity(intent);
    }
}